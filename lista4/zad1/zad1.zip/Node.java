abstract class Node {
    String key;
    Structure structure;
    Node left, right, parent;
    Integer color;
}